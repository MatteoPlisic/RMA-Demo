package com.example

import io.ktor.server.application.*

import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import org.slf4j.event.*

fun Application.configureRouting() {
    routing {
        get("/") {
            call.respondText("Hello World!")
        }
        get("/students") {
            val students = listOf(
                Student("John", "Doe", "2000-01-01", true, 4.5),
                Student("Jane", "Smith", "1999-12-12", false, 4.7),
                Student("Mark", "Lee", "2001-03-15", true, 4.2),
                Student("Emily", "Johnson", "2000-05-20", false, 4.8),
                Student("Michael", "Brown", "1998-11-02", true, 3.9),
                Student("Olivia", "Davis", "2002-07-14", false, 4.6),
                Student("William", "Garcia", "2001-01-29", true, 4.1),
                Student("Sophia", "Martinez", "2000-10-10", false, 4.9),
                Student("Daniel", "Rodriguez", "1999-04-17", true, 4.3),
                Student("Ava", "Wilson", "2003-03-03", false, 4.0),
                Student("James", "Anderson", "2001-06-25", true, 3.8),
                Student("Isabella", "Taylor", "2002-09-18", false, 4.7),
                Student("Benjamin", "Thomas", "2000-08-08", true, 4.4),
                Student("Mia", "Hernandez", "1999-02-12", false, 3.7),
                Student("Elijah", "Moore", "2001-12-05", true, 4.6),
                Student("Charlotte", "Martin", "2003-01-19", false, 4.3),
                Student("Logan", "Jackson", "2000-06-09", true, 3.5),
                Student("Amelia", "White", "1998-07-30", false, 4.5),
                Student("Lucas", "Lopez", "2002-04-22", true, 4.1),
                Student("Harper", "Clark", "2001-11-13", false, 4.4),
                Student("Mason", "Lewis", "1999-03-11", true, 4.0),
                Student("Evelyn", "Walker", "2000-12-24", false, 4.2),
                Student("Henry", "Hall", "1998-05-05", true, 4.6)
            )
            call.respond(students)
        }
    }
}
