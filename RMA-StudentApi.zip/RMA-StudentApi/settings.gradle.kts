rootProject.name = "RMA-StudentApi"
